/* SPDX-FileCopyrightText: 2014-present Kriasoft */
/* SPDX-License-Identifier: MIT */

/**
 * Cloudflare Workers content manifest fallback (for unit testing).
 */
export default "{}";
